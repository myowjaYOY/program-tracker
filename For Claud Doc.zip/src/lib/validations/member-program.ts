import { z } from 'zod';

// Program type enum for validation
export const programTypeEnum = z.enum(['one-time', 'membership']);
export type ProgramType = z.infer<typeof programTypeEnum>;

export const memberProgramSchema = z.object({
  program_template_name: z.string().min(1, 'Program Name is required'),
  description: z.string().nullable().optional(),
  lead_id: z.number().nullable().optional(),
  start_date: z.string().nullable().optional(),
  duration: z.number().min(1, 'Duration must be at least 1'),
  program_status_id: z.number().nullable().optional(),
  active_flag: z.boolean().optional(),
  // Membership program fields (program_type defaults to 'one-time' in database)
  program_type: programTypeEnum.optional(),
  next_billing_date: z.string().nullable().optional(),
});

// Schema for creating a membership program (duration not required)
export const membershipProgramSchema = memberProgramSchema.omit({ duration: true }).extend({
  program_type: z.literal('membership'),
  duration: z.number().nullable().optional(), // Duration not used for memberships
});

// Schema for creating a one-time program (duration required)
export const oneTimeProgramSchema = memberProgramSchema.extend({
  program_type: z.literal('one-time'),
});

export const memberProgramUpdateSchema = memberProgramSchema.partial();
export type MemberProgramFormData = z.infer<typeof memberProgramSchema>;
export type MembershipProgramFormData = z.infer<typeof membershipProgramSchema>;
export type OneTimeProgramFormData = z.infer<typeof oneTimeProgramSchema>;
