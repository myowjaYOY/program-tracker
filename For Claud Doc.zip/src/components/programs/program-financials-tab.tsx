'use client';

import React from 'react';
import {
  Box,
  Grid,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Typography,
  Card,
  CardContent,
  Button,
  CircularProgress,
  Alert,
  Chip,
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import { formatCurrency } from '@/lib/utils/money';
import FormStatus from '@/components/ui/FormStatus';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
// import { toast } from 'sonner';
import { MemberPrograms } from '@/types/database.types';
import {
  memberProgramFinancesSchema,
  MemberProgramFinancesFormData,
} from '@/lib/validations/member-program-finances';
import {
  useMemberProgramFinances,
  useCreateMemberProgramFinances,
  useUpdateMemberProgramFinances,
} from '@/lib/hooks/use-member-program-finances';
import {
  useMemberProgramPayments,
  useRegenerateMemberProgramPayments,
} from '@/lib/hooks/use-member-program-payments';
import { useActiveFinancingTypes } from '@/lib/hooks/use-financing-types';
import { useMemberProgram } from '@/lib/hooks/use-member-programs';
import { useMemberProgramItems } from '@/lib/hooks/use-member-program-items';
import { useProgramStatus } from '@/lib/hooks/use-program-status';
import { isProgramLocked } from '@/lib/utils/program-lock';
import useFinancialsLock from '@/lib/hooks/use-financials-lock';
import { useFinancialsDerived } from '@/lib/hooks/use-financials-derived';
import { shouldRegeneratePayments } from '@/lib/utils/payments-rules';
import { isProgramReadOnly, getReadOnlyMessage } from '@/lib/utils/program-readonly';
import { useMembershipFinances } from '@/lib/hooks/use-membership-finances';
import { calculateMonthlyPayment } from '@/lib/validations/member-program-membership-finances';

interface ProgramFinancialsTabProps {
  program: MemberPrograms;
  onFinancesUpdate?: (updatedFinances: MemberProgramFinancesFormData) => void;
  onUnsavedChangesChange?: (hasChanges: boolean) => void;
}

export default function ProgramFinancialsTab({
  program,
  onFinancesUpdate,
  onUnsavedChangesChange,
}: ProgramFinancialsTabProps) {
  const theme = useTheme();
  // Fetch existing finances data
  const {
    data: existingFinances,
    isLoading: isLoadingFinances,
    error: financesError,
  } = useMemberProgramFinances(program.member_program_id);

  // Fetch financing types for dropdown
  const { data: financingTypes = [], isLoading: isLoadingFinancingTypes } =
    useActiveFinancingTypes();

  // Mutations
  const createFinances = useCreateMemberProgramFinances();
  const updateFinances = useUpdateMemberProgramFinances();
  const regeneratePayments = useRegenerateMemberProgramPayments();
  const { data: payments = [] } = useMemberProgramPayments(
    program.member_program_id
  );
  const { data: freshProgram } = useMemberProgram(program.member_program_id);
  const { data: allStatuses = [] } = useProgramStatus();
  
  // Fetch program items to calculate taxable charge
  const { data: programItems = [] } = useMemberProgramItems(program.member_program_id);

  // Calculate total taxable charge from items
  const totalTaxableCharge = React.useMemo(() => {
    return (programItems || []).reduce((sum: number, item: any) => {
      const quantity = item.quantity || 1;
      const charge = item.item_charge || 0;
      const isTaxable = item.therapies?.taxable === true;
      
      if (isTaxable) {
        return sum + (charge * quantity);
      }
      return sum;
    }, 0);
  }, [programItems]);

  const paidTotal = React.useMemo(() => {
    return (payments || []).reduce((sum: number, p: any) => {
      const isPaid = !!p?.payment_date;
      const amt = Number(p?.payment_amount || 0);
      return isPaid ? sum + amt : sum;
    }, 0);
  }, [payments]);
  const hasPaidPayment = React.useMemo(
    () => (payments || []).some((p: any) => !!p?.payment_date),
    [payments]
  );
  const lock = useFinancialsLock(freshProgram || program, payments as any);
  const isLockedByStatus = lock.isLockedByStatus;
  const isLocked = lock.locked;
  const [baselineVersion, setBaselineVersion] = React.useState(0);

  // Check if program is in read-only state (Completed or Cancelled)
  const currentStatus = allStatuses.find(
    s => s.program_status_id === (freshProgram?.program_status_id ?? program.program_status_id)
  );
  const isReadOnly = isProgramReadOnly(currentStatus?.status_name);
  const readOnlyMessage = getReadOnlyMessage(currentStatus?.status_name);

  const {
    register,
    handleSubmit,
    control,
    watch,
    getValues,
    setValue,
    reset,
    trigger,
    formState: { errors, isDirty, dirtyFields },
  } = useForm<MemberProgramFinancesFormData>({
    resolver: zodResolver(memberProgramFinancesSchema),
    defaultValues: {
      member_program_id: program.member_program_id,
      finance_charges: 0,
      discounts: 0,
      final_total_price: 0,
      margin: 0,
      financing_type_id: undefined,
    },
  });

  // Watch for changes to calculate totals
  const watchedValues = watch();
  const financingTypeSelected = watch('financing_type_id');

  // Margin color thresholds: green ≥80, orange ≥75 and <80, red <75
  const marginValue = Number(watchedValues.margin || 0);
  const marginColor =
    marginValue >= 80
      ? theme.palette.success.main
      : marginValue >= 75
        ? theme.palette.warning.main
        : theme.palette.error.main;
  const originalFinancingTypeIdRef = React.useRef<number | undefined>(
    undefined
  );
  const originalFinanceChargesRef = React.useRef<number>(0);
  const originalDiscountsRef = React.useRef<number>(0);

  // Local display states for currency inputs to allow free typing
  const [discountsInput, setDiscountsInput] = React.useState<string>('$0.00');
  const [financeChargesInput, setFinanceChargesInput] =
    React.useState<string>('$0.00');

  const formatCurrencyInline = (n: number): string =>
    `$${Number(n || 0).toFixed(2)}`;
  const roundToCents = (n: number): number => Math.round(n * 100) / 100;
  const sanitizeNumeric = (input: string): string => {
    let s = input.replace(/[^0-9.]/g, '');
    const firstDot = s.indexOf('.');
    if (firstDot !== -1) {
      s = s.slice(0, firstDot + 1) + s.slice(firstDot + 1).replace(/\./g, '');
    }
    return s;
  };
  // Prevent initial derived setValue from marking form dirty
  const hasInitializedDerived = React.useRef(false);
  const sanitizeNumericAllowNegative = (input: string): string => {
    let s = input.replace(/[^0-9.-]/g, '');
    // keep only leading '-'
    if (s.startsWith('-')) {
      s = '-' + s.slice(1).replace(/-/g, '');
    } else {
      s = s.replace(/-/g, '');
    }
    // keep only first '.'
    const firstDot = s.indexOf('.');
    if (firstDot !== -1) {
      s = s.slice(0, firstDot + 1) + s.slice(firstDot + 1).replace(/\./g, '');
    }
    return s;
  };
  const sanitizePercentTyping = (
    input: string,
    allowNegative: boolean
  ): string => {
    let s = input.replace(allowNegative ? /[^0-9.%-]/g : /[^0-9.%]/g, '');
    if (allowNegative) {
      if (s.startsWith('-')) s = '-' + s.slice(1).replace(/-/g, '');
      else s = s.replace(/-/g, '');
    } else {
      s = s.replace(/-/g, '');
    }
    const hasPct = s.endsWith('%');
    const core = hasPct ? s.slice(0, -1) : s;
    const dot = core.indexOf('.');
    const cleaned =
      dot === -1
        ? core
        : core.slice(0, dot + 1) + core.slice(dot + 1).replace(/\./g, '');
    return hasPct ? cleaned + '%' : cleaned;
  };
  const convertPercentStringToAmount = (
    raw: string,
    base: number,
    forceNegative: boolean
  ): number | null => {
    if (!raw.trim().endsWith('%')) return null;
    const isNeg = raw.trim().startsWith('-');
    const v = parseFloat(raw.trim().replace('%', '').replace('+', ''));
    if (Number.isNaN(v)) return null;
    const pct = Math.min(Math.max(Math.abs(v), 0), 100);
    let amount = roundToCents(base * (pct / 100));
    if (forceNegative) amount = -Math.abs(amount);
    else amount = isNeg ? -amount : amount;
    return amount;
  };

  // Determine if program is Active
  const statusName = (
    allStatuses.find(
      s =>
        s.program_status_id ===
        (freshProgram?.program_status_id ?? program.program_status_id)
    )?.status_name || ''
  ).toLowerCase();
  const isActiveProgramStatus = statusName === 'active';

  // Derived values via shared hook
  const { programPrice: derivedProgramPrice, margin: derivedMargin, taxes: derivedTaxes } =
    useFinancialsDerived({
      totalCharge: Number(program.total_charge || 0),
      totalCost: Number(program.total_cost || 0),
      financeCharges: Number(watchedValues.finance_charges || 0),
      discounts: Number(watchedValues.discounts || 0),
      taxes: Number(existingFinances?.taxes || 0),
      totalTaxableCharge: totalTaxableCharge,
      isActive: isActiveProgramStatus,
      lockedPrice: Number(existingFinances?.final_total_price || 0),
      variance: Number(existingFinances?.variance || 0),
    });

  // Load existing data when available
  React.useEffect(() => {
    if (existingFinances) {
      reset({
        member_program_id: program.member_program_id,
        finance_charges: existingFinances.finance_charges || 0,
        discounts: existingFinances.discounts || 0,
        final_total_price: existingFinances.final_total_price || 0,
        margin: existingFinances.margin || 0,
        financing_type_id: existingFinances.financing_type_id || undefined,
      });
      setDiscountsInput(formatCurrencyInline(existingFinances.discounts || 0));
      setFinanceChargesInput(
        formatCurrencyInline(existingFinances.finance_charges || 0)
      );
      originalFinancingTypeIdRef.current =
        existingFinances.financing_type_id || undefined;
      originalFinanceChargesRef.current = Number(
        existingFinances.finance_charges || 0
      );
      originalDiscountsRef.current = Number(existingFinances.discounts || 0);
      // No local baseline; banner will compare against last-saved finances
    }
    // Reset unsaved flag when (re)loading data for this program
    onUnsavedChangesChange?.(false);
  }, [existingFinances, program.member_program_id, reset]);

  // Reflect derived values into form state as needed (without breaking dirtiness semantics)
  React.useEffect(() => {
    const currentFinal = getValues('final_total_price');
    const currentMargin = getValues('margin');
    const baseInputsDirty = !!(
      dirtyFields.finance_charges ||
      dirtyFields.discounts
    );
    const markDirty = hasInitializedDerived.current && baseInputsDirty;
    if (currentFinal !== derivedProgramPrice) {
      setValue('final_total_price', derivedProgramPrice, {
        shouldDirty: markDirty,
      });
    }
    if (currentMargin !== derivedMargin) {
      setValue('margin', derivedMargin, { shouldDirty: markDirty });
    }
    if (!hasInitializedDerived.current) {
      hasInitializedDerived.current = true;
    }
  }, [
    derivedProgramPrice,
    derivedMargin,
    dirtyFields.finance_charges,
    dirtyFields.discounts,
    getValues,
    setValue,
  ]);

  const [inline, setInline] = React.useState<{
    ok: boolean;
    message: string;
  } | null>(null);

  // Auto-hide success message after a short delay
  React.useEffect(() => {
    if (inline?.ok) {
      const t = setTimeout(() => setInline(null), 4000);
      return () => clearTimeout(t);
    }
    return undefined;
  }, [inline]);

  const onSubmit = async (data: MemberProgramFinancesFormData) => {
    try {
      // Sanitize fields before sending to API (avoid '' for optional numbers)
      const safeFinancingTypeId =
        typeof (data as any).financing_type_id === 'number'
          ? (data as any).financing_type_id
          : undefined;

      const payload = {
        finance_charges: Number(data.finance_charges || 0),
        discounts: Number(data.discounts || 0),
        final_total_price: Number(data.final_total_price || 0),
        margin: Number(data.margin || 0),
        taxes: derivedTaxes, // Use calculated taxes from derived hook
        financing_type_id: safeFinancingTypeId,
      } as Partial<MemberProgramFinancesFormData>;
      setInline(null);
      if (existingFinances) {
        // Update existing record
        await updateFinances.mutateAsync({
          programId: program.member_program_id,
          data: payload,
        });
      } else {
        // Create new record
        await createFinances.mutateAsync({
          programId: program.member_program_id,
          data: {
            ...(payload as any),
            member_program_id: program.member_program_id,
          },
        });
      }
      // Unified payments update logic - skip for memberships (payments are generated monthly, not regenerated)
      if (!isMembership) {
        const paymentsExist = (payments?.length || 0) > 0;
        const shouldRegenerate = shouldRegeneratePayments({
          paymentsExist,
          originalFinancingTypeId: originalFinancingTypeIdRef.current ?? null,
          nextFinancingTypeId: (data.financing_type_id ?? null) as number | null,
          originalFinanceCharges: originalFinanceChargesRef.current,
          nextFinanceCharges: Number(data.finance_charges || 0),
          originalDiscounts: originalDiscountsRef.current,
          nextDiscounts: Number(data.discounts || 0),
        });
        if (shouldRegenerate) {
          try {
            await regeneratePayments.mutateAsync({
              programId: program.member_program_id,
            });
          } catch (e: any) {
            setInline({
              ok: false,
              message: e?.message || 'Failed to update payments',
            });
            return;
          }
        }
      } else {
        // no-op
      }
      // Update baselines after save (and potential regeneration)
      originalFinancingTypeIdRef.current = safeFinancingTypeId || undefined;
      originalFinanceChargesRef.current = Number(payload.finance_charges || 0);
      originalDiscountsRef.current = Number(payload.discounts || 0);
      setBaselineVersion(v => v + 1);

      onFinancesUpdate?.(data);
      onUnsavedChangesChange?.(false);
      setInline({ ok: true, message: 'Changes saved successfully' });
    } catch (error: any) {
      const msg =
        (error && (error.message || error.toString())) ||
        'Failed to save program finances';
      setInline({ ok: false, message: msg });
    }
  };

  // Compute and notify material changes (compare against latest baselines in refs)
  React.useEffect(() => {
    // Avoid false positives during load/save transitions
    if (
      isLoadingFinances ||
      createFinances.isPending ||
      updateFinances.isPending
    ) {
      onUnsavedChangesChange?.(false);
      return;
    }

    const typeChanged =
      (originalFinancingTypeIdRef.current ?? null) !==
      (financingTypeSelected ?? null);
    const fcCurr = roundToCents(Number(watchedValues.finance_charges || 0));
    const fcBase = roundToCents(originalFinanceChargesRef.current);
    const discCurr = roundToCents(Number(watchedValues.discounts || 0));
    const discBase = roundToCents(originalDiscountsRef.current);

    const financeChargesChanged = fcBase !== fcCurr;
    const discountsChanged = discBase !== discCurr;

    const changed =
      typeChanged || financeChargesChanged || discountsChanged;
    onUnsavedChangesChange?.(changed);
  }, [
    isLoadingFinances,
    createFinances.isPending,
    updateFinances.isPending,
    financingTypeSelected,
    watchedValues.finance_charges,
    watchedValues.discounts,
    baselineVersion,
    onUnsavedChangesChange,
  ]);

  // Local hasChanges for Save button state
  const hasChanges = React.useMemo(() => {
    const typeChanged =
      (originalFinancingTypeIdRef.current ?? null) !==
      (financingTypeSelected ?? null);
    const fcCurr = roundToCents(Number(watchedValues.finance_charges || 0));
    const fcBase = roundToCents(originalFinanceChargesRef.current);
    const discCurr = roundToCents(Number(watchedValues.discounts || 0));
    const discBase = roundToCents(originalDiscountsRef.current);
    return (
      typeChanged ||
      fcBase !== fcCurr ||
      discBase !== discCurr
    );
  }, [
    financingTypeSelected,
    watchedValues.finance_charges,
    watchedValues.discounts,
    baselineVersion,
  ]);

  // Would the current edits require payments regeneration?
  const wouldRegenerate = React.useMemo(() => {
    const typeChanged =
      (originalFinancingTypeIdRef.current ?? null) !==
      (financingTypeSelected ?? null);
    const fcCurr = roundToCents(Number(watchedValues.finance_charges || 0));
    const fcBase = roundToCents(originalFinanceChargesRef.current);
    const discCurr = roundToCents(Number(watchedValues.discounts || 0));
    const discBase = roundToCents(originalDiscountsRef.current);
    return typeChanged || fcBase !== fcCurr || discBase !== discCurr;
  }, [
    financingTypeSelected,
    watchedValues.finance_charges,
    watchedValues.discounts,
    baselineVersion,
  ]);

  const isSaving = createFinances.isPending || updateFinances.isPending;
  const isLoading = isLoadingFinances;

  // Warn if discounts changed after finance charges were populated (percent base changed)
  const financeChargesNeedsRecalc = React.useMemo(() => {
    const fc = Number(watchedValues.finance_charges || 0);
    const currDisc = roundToCents(Number(watchedValues.discounts || 0));
    const origDisc = roundToCents(originalDiscountsRef.current);
    return !isLocked && fc !== 0 && currDisc !== origDisc;
  }, [watchedValues.finance_charges, watchedValues.discounts, isLocked]);

  // Determine if this is a membership program
  const isMembership = program.program_type === 'membership';

  // Fetch membership finances for membership programs
  const { data: membershipFinances, isLoading: isLoadingMembershipFinances } = 
    useMembershipFinances(program.member_program_id, isMembership);

  // Calculate monthly payment from membership finances
  const monthlyPayment = React.useMemo(() => {
    if (!membershipFinances) return 0;
    return calculateMonthlyPayment({
      monthly_rate: membershipFinances.monthly_rate || 0,
      monthly_discount: membershipFinances.monthly_discount || 0,
      monthly_finance_charge: membershipFinances.monthly_finance_charge || 0,
    });
  }, [membershipFinances]);

  // Format Member Since date for membership banner
  const memberSinceFormatted = React.useMemo(() => {
    if (!program.start_date) return { display: 'Not set', months: 0 };
    const startDate = new Date(program.start_date);
    const now = new Date();
    const monthsDiff = (now.getFullYear() - startDate.getFullYear()) * 12 + 
                       (now.getMonth() - startDate.getMonth());
    const display = startDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    return { display, months: Math.max(0, monthsDiff) };
  }, [program.start_date]);

  if (financesError) {
    return (
      <Alert severity="error" sx={{ mb: 2 }}>
        Failed to load program finances: {financesError.message}
      </Alert>
    );
  }

  return (
    <Box component="form" onSubmit={handleSubmit(onSubmit)}>
      {isReadOnly && (
        <Alert severity="warning" sx={{ mb: 2 }}>
          {readOnlyMessage}
        </Alert>
      )}
      {isLocked && !isReadOnly && (
        <Alert severity="warning" sx={{ mb: 2 }}>
          Program must be in Quote status to change any information on this
          tab.
        </Alert>
      )}

      {/* Membership Summary Row - Only shown for membership programs */}
      {isMembership && (
        <Grid container spacing={3} sx={{ mb: 3 }}>
          <Grid size={{ xs: 12, md: 4 }}>
            <TextField
              label="Monthly Payment"
              fullWidth
              disabled
              value={isLoadingMembershipFinances ? 'Loading...' : formatCurrency(monthlyPayment)}
              InputProps={{ readOnly: true }}
            />
          </Grid>
          <Grid size={{ xs: 12, md: 4 }}>
            <TextField
              label="Monthly Discount"
              fullWidth
              disabled
              value={isLoadingMembershipFinances ? 'Loading...' : formatCurrency(membershipFinances?.monthly_discount || 0)}
              InputProps={{ readOnly: true }}
            />
          </Grid>
          <Grid size={{ xs: 12, md: 4 }}>
            <TextField
              label="Member Since"
              fullWidth
              disabled
              value={`${memberSinceFormatted.display} (${memberSinceFormatted.months} months)`}
              InputProps={{ readOnly: true }}
            />
          </Grid>
        </Grid>
      )}

      <Card>
        <CardContent>
          <fieldset disabled={isReadOnly} style={{ border: 'none', padding: 0, margin: 0 }}>
          {/* Section title for memberships */}
          {isMembership && (
            <Typography variant="subtitle2" color="text.secondary" sx={{ mb: 2, fontWeight: 600 }}>
              PROGRAM TOTALS (CUMULATIVE)
            </Typography>
          )}
          <Grid container spacing={3}>
            {/* Row 1: Items Cost, Items Charge, Margin */}
            <Grid size={{ xs: 12, md: 4 }}>
              <TextField
                label="Items Cost"
                fullWidth
                disabled
                value={formatCurrency(Number(program.total_cost || 0))}
                InputProps={{ readOnly: true }}
                helperText="Sum of all item costs"
              />
            </Grid>
            <Grid size={{ xs: 12, md: 4 }}>
              <TextField
                label="Items Charge"
                fullWidth
                disabled
                value={formatCurrency(Number(program.total_charge || 0))}
                InputProps={{ readOnly: true }}
                helperText="Does Not Include Finance Charges or Discounts"
              />
            </Grid>
            <Grid size={{ xs: 12, md: 4 }}>
              <TextField
                label="Margin (%)"
                fullWidth
                disabled
                value={`${Number(watchedValues.margin || 0).toFixed(2)}%`}
                InputProps={{ readOnly: true }}
                helperText="Calculated on pre-tax revenue"
                sx={{
                  '& .MuiInputBase-input.Mui-disabled': {
                    WebkitTextFillColor: marginColor,
                    color: marginColor,
                    fontWeight: 600,
                  },
                }}
              />
            </Grid>

            {/* Row 2: Financing Type (one-time only), Discount, Finance Charges (one-time only) */}
            {/* Financing Type - Hidden for memberships (always Full Pay) */}
            {!isMembership && (
              <Grid size={{ xs: 12, md: 4 }}>
                <FormControl fullWidth error={!!errors.financing_type_id}>
                  <InputLabel>Financing Type</InputLabel>
                  <Controller
                    name="financing_type_id"
                    control={control}
                    render={({ field }) => (
                      <Select
                        {...field}
                        label="Financing Type"
                        value={field.value || ''}
                        disabled={isLoadingFinancingTypes || isLocked}
                      >
                        <MenuItem value="">
                          <em>None</em>
                        </MenuItem>
                        {financingTypes.map(type => (
                          <MenuItem
                            key={type.financing_type_id}
                            value={type.financing_type_id}
                          >
                            {type.financing_type_name}
                          </MenuItem>
                        ))}
                      </Select>
                    )}
                  />
                  {errors.financing_type_id && (
                    <Typography
                      variant="caption"
                      color="error"
                      sx={{ mt: 0.5, ml: 1.75 }}
                    >
                      {errors.financing_type_id.message}
                    </Typography>
                  )}
                </FormControl>
              </Grid>
            )}
            {/* Finance Charges - Hidden for memberships */}
            {!isMembership && (
              <Grid size={{ xs: 12, md: 4 }}>
                <Controller
                  name="finance_charges"
                  control={control}
                  render={({ field }) => (
                    <Box
                      sx={{ display: 'flex', gap: 1, alignItems: 'flex-start' }}
                    >
                      <TextField
                        label="Finance Charges"
                        fullWidth
                        error={!!errors.finance_charges}
                        helperText={
                          errors.finance_charges?.message ||
                          (Number(watchedValues.finance_charges || 0) > 0
                            ? 'Positive: Increases Program Price; already counted in revenue'
                            : Number(watchedValues.finance_charges || 0) < 0
                              ? 'Negative: Does not reduce price, but lowers margin'
                              : 'Enter amount or % (e.g., 5%)')
                        }
                        value={financeChargesInput}
                        onFocus={() =>
                          setFinanceChargesInput(String(field.value ?? ''))
                        }
                        onChange={e => {
                          const raw = sanitizePercentTyping(e.target.value, true);
                          setFinanceChargesInput(raw);
                          if (!raw.endsWith('%')) {
                            const num =
                              raw === '' || raw === '-' ? 0 : parseFloat(raw);
                            field.onChange(Number.isNaN(num) ? 0 : num);
                          }
                        }}
                        onBlur={() => {
                          const itemsCharge = Number(program.total_charge || 0);
                          const discounts = Number(watchedValues.discounts || 0);
                          const base = Math.max(0, itemsCharge + discounts);
                          const converted = convertPercentStringToAmount(
                            financeChargesInput,
                            base,
                            false
                          );
                          if (converted !== null) {
                            field.onChange(converted);
                            setFinanceChargesInput(
                              formatCurrencyInline(converted)
                            );
                          } else {
                            setFinanceChargesInput(
                              formatCurrencyInline(field.value || 0)
                            );
                          }
                        }}
                        disabled={isLocked || !financingTypeSelected}
                      />
                      <Chip
                        label={
                          Number(watchedValues.finance_charges || 0) > 0
                            ? 'Included in Price'
                            : Number(watchedValues.finance_charges || 0) < 0
                              ? 'Affects Margin'
                              : '—'
                        }
                        color={
                          Number(watchedValues.finance_charges || 0) > 0
                            ? 'primary'
                            : Number(watchedValues.finance_charges || 0) < 0
                              ? 'warning'
                              : 'default'
                        }
                        variant="outlined"
                        sx={{ mt: 0.5 }}
                      />
                    </Box>
                  )}
                />
              </Grid>
            )}
            <Grid size={{ xs: 12, md: 4 }}>
              <Controller
                name="discounts"
                control={control}
                render={({ field }) => (
                  <TextField
                    label="Discounts"
                    fullWidth
                    error={!!errors.discounts}
                    helperText={errors.discounts?.message || 'Enter amount or % (e.g., 10%)'}
                    value={discountsInput}
                    onFocus={() => setDiscountsInput(String(field.value ?? ''))}
                    onChange={e => {
                      const raw = sanitizePercentTyping(e.target.value, true);
                      setDiscountsInput(raw);
                      if (!raw.endsWith('%')) {
                        const num =
                          raw === '' || raw === '-' ? 0 : parseFloat(raw);
                        field.onChange(Number.isNaN(num) ? 0 : -Math.abs(num));
                      }
                    }}
                    onBlur={() => {
                      const base = Number(program.total_charge || 0);
                      const converted = convertPercentStringToAmount(
                        discountsInput,
                        base,
                        true
                      );
                      if (converted !== null) {
                        field.onChange(converted);
                        setDiscountsInput(formatCurrencyInline(converted));
                      } else {
                        field.onChange(-Math.abs(Number(field.value || 0)));
                        setDiscountsInput(
                          formatCurrencyInline(
                            -Math.abs(Number(field.value || 0))
                          )
                        );
                      }
                    }}
                    disabled={isLocked}
                  />
                )}
              />
              {financeChargesNeedsRecalc && (
                <Typography variant="caption" color="warning.main" sx={{ mt: 0.5 }}>
                  Discount changed: Finance Charges may be outdated. Recalculate.
                </Typography>
              )}
            </Grid>

            {/* Row 3: Final Total Price and Taxes */}
            <Grid size={{ xs: 12, md: 4 }}>
              <TextField
                label="Program Price"
                fullWidth
                disabled
                value={formatCurrency(Number(derivedProgramPrice || 0))}
                InputProps={{ readOnly: true }}
                helperText="Includes Taxes"
              />
            </Grid>
            <Grid size={{ xs: 12, md: 4 }}>
              <TextField
                label="Taxes"
                fullWidth
                disabled
                value={formatCurrency(derivedTaxes)}
                InputProps={{ readOnly: true }}
                helperText="Calculated from taxable items (8.25%)"
              />
            </Grid>
            {/* Credit - Hidden for memberships */}
            {!isMembership && (
              <Grid size={{ xs: 12, md: 4 }}>
                <TextField
                  label="Credit"
                  fullWidth
                  disabled
                  value={formatCurrency(
                    Number(-(existingFinances?.variance || 0))
                  )}
                  InputProps={{ readOnly: true }}
                />
              </Grid>
            )}
          </Grid>

          {/* Actions */}
          <Box
            sx={{
              mt: 3,
              display: 'flex',
              justifyContent: 'flex-end',
              alignItems: 'center',
              gap: 2,
            }}
          >
            <FormStatus status={inline} onClose={() => setInline(null)} />
            <Button
              type="submit"
              variant="contained"
              color="primary"
              disabled={isLocked || !hasChanges || isLoading || isSaving}
              startIcon={isSaving ? <CircularProgress size={16} /> : null}
              sx={{ borderRadius: 0, fontWeight: 600 }}
            >
              {isSaving ? 'Saving...' : (isMembership ? 'Save' : 'Save and Update Payments')}
            </Button>
          </Box>
          </fieldset>
        </CardContent>
      </Card>
    </Box>
  );
}
